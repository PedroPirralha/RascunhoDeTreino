#test request

import requests
'''
requisição = requests.get('http://cbn.globoradio.globo.com/media/audio/299406/para-concentra-44-de-toda-area-desmatada-da-amazon.htm')

print(type(requisição))  #return: <class 'requests.models.Response'>
print(requisição)  #return <response [200]>
print(requisição.text) #return Retorna o script html da pagina

'''

#tratando de erros #deixando o codigo mais bonito

cabecalho = {'USER-AGENT':'Windows Piratao mod',        # da para udar varias informações do headers por aqui
             'REFERER':'Google.com mod', }  
meus_cookies = {'Ultima-visita':'10/11/2019'}
dados = {'username':'Pepedro',
         'password':'1221321'}


site1 = 'http://google.com/'
site2 = 'http://cbn.globoradio.globo.com/media/audio/299406/para-concentra-44-de-toda-area-desmatada-da-amazon.htm'
site3 = 'http://site.com.erro.br'
site4 = 'https://putsreq.com/JTp6VaZatuZQaHasGWZH' #site para criar request http//:putsreq.com


texto = None
try:
    requisicao = requests.post(site4,headers=cabecalho,cookies=meus_cookies, data=dados)
    texto = requisicao.text
except Exception as e:
    print('--- ERRO ---\nRequisição deu erro ..:',e)
print(texto)