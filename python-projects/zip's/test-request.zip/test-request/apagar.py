
tst = open ("/home/pedro/Documentos/Projetos_Programação/Projetos Abertos/python-projects/Requests/.p.txt")
test = open("/home/pedro/Documentos/Projetos_Programação/Projetos Abertos/python-projects/Requests/.E.txt")

tesst = (test.readlines())  #email
tst = (tst.readlines())     #password
print('\n')
print('login {} \nsenha {} \n'.format(tesst, tst))
for x in range(1,len(tesst)+1):
    print('\n')
    print('Primeiro for',x-1)
    
    for a in range(1, len(tst)+1):
        print('segundo for')
        print(tesst[x-1].replace('\n','  '),tst[a-1].replace('\n','  '))
        print('\n')
        




