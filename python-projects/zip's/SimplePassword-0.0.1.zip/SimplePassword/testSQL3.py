import sqlite3 as sql

banc = sql.connect('/home/pedro/Documentos/Projetos_Programação/Projetos Abertos/python-projects/SimplePassword/pass.db')
dataBanc = banc.cursor()

#dataBanc.execute("CREATE TABLE password (name text, pass text)")
#dataBanc.execute("INSERT INTO password VALUES('facebook', '1221321')")
#banc.commit()
#dataBanc.execute("DELETE from password WHERE name = x")
dataBanc.execute("SELECT * FROM password")
print(dataBanc.fetchall())
banc.commit()

banc.close()
