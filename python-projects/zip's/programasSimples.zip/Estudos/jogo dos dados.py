# jogo dos dados #
import random

num_dado1 = [1, 2, 3, 4, 5, 6, 7, 8, 9 ]
num_dado2 = [1, 2, 3, 4, 5, 6, 7, 8, 9 ]


num_sort1 = random.choice(num_dado1)
num_sort2 = random.choice(num_dado2)





print(num_sort1,'_' ,num_sort2)