import  pandas as pd 

data_frame = {'nomes':['joão','Pedro','felipe','hamster','bianca','xablau','união flasco']}


dt = pd.DataFrame(data_frame)
