import numpy as np
import func_ as fc
'''d1 = np.array([4,5,6])
d2 = np.array([(3,2,1),(1,2,3)])
d3 = np.array([(3,2,1),(1,2,3),(6,5,4)])
matriz0 = np.zeros((11,15))
matriz1 = np.ones((6,3))
matrizeye = np.eye((5),(5),(0))
maxd = d3.max()
mind = d3.min()
sumd = d3.sum()
meand = d3.mean()
std_d = d3.std()'''
fc.clear_t()

dimension_one = np.array([('-','-','-'),('-','-','-')])
print(dimension_one)