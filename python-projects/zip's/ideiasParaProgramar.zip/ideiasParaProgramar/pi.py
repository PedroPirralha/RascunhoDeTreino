
def circuferencia(diametro):
	c = diametro * 3.1415
	return float(c)
def pi(circuferencia,diametro):
	p = circuferencia/diametro
	return float(p)



print('{:.4f}\n{:.4f}'.format(pi(circuferencia(31), 31),circuferencia(31)))

