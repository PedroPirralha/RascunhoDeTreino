from collections import namedtuple
"""parte feita apenas para colocar a data comumente usada no brasil"""
import datetime
today = datetime.date.today()
print(type(today))
str_today = today.strftime('%y%y %m %d').split(' ')
print(type(str_today))
str_today = ('-'.join(str_today[::-1]))
print(type(str_today))
print('data de hoje :',str_today)

"""namedtuple +/- = a def and class """
info = namedtuple('info','sobrenome_nome sobrenome nacionalidade idade')
joao = info(sobrenome_nome = 'joão Henrique', sobrenome='henrique',idade=31, nacionalidade='brazil')
pedro = info(sobrenome_nome='Pedro Quadros', sobrenome='Quadros', idade=55, nacionalidade='bazil')
'''nome = input('digite seu nome : ')
sobrenome = input('digite apenas o sobre nome :')
sobrenomenome = input('digite sobre nome e nome : ')
idade_ = input('digite sua idade :')
nacionalidade = input('digite seu pais de origem')'''
print(joao)
print(pedro)
