def fibonacci (start, end):
    x1 = start
    x2 = start
    fibb = []
    print(start, start, end=" ")
    for x in range(0, end):
        x3 = x1 + x2
        x1 = x2
        x2 = x3
        fibb.append(x3)
    return fibb
