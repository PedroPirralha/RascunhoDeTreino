import random
somax = []
for c in range(0,10):
       d1 = d2 = d3 = d4 = d5 = d6 = d7 = d8 = d9 = d10 = 1, 2, 3, 4, 5, 6, 7, 8, 9, 0
       soma = random.choice(d1) + random.choice(d2) + \
           random.choice(d3) + random.choice(d4) + \
           random.choice(d5) + random.choice(d6) + \
           random.choice(d7) + random.choice(d8) + \
           random.choice(d9) + random.choice(d10)
       print('{}  {}  {}  {}  {}  {}  {}  {}  {}  {}       {}'.format(random.choice(d1),random.choice(d2),
                                                                   random.choice(d3),random.choice(d4),
                                                                   random.choice(d5),random.choice(d6),
                                                                   random.choice(d7),random.choice(d8),
                                                                   random.choice(d9),random.choice(d10),soma ))
       somax.append(soma)

print('o soma de todos os numeros é {}'.format(sum(somax)))