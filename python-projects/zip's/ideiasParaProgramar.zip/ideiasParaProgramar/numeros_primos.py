## Prime factors ##
x = int(input('digite um numero :'))
x1 = 3
for c in range(0, x):
    if x == 3 or x == 2 or x == 1:
        print('esses numero e primoio', x)
        break
    if x == 4:
        print('esse numero não e primoio',x)
        break
    if x % x1 != 0 :
        if x//x1==1:
            print('esse numero e primo',x)
            break
        x1 += 1
    elif x > x1:
        print('esse numero não e primo ',x)
        break
    else:
        x1 += 1
'''-----------------------segundo verificador--------------------------------'''
def num_prim(numero_primo):

    tot = 0
    for c in range(1, numero_primo+1):
        #print(tot)
        if  numero_primo % c == 0:
            tot+=1
    if tot == 2:
        print('esse numero e primo')
        #print(tot)
    else:
        print('esse numero não e primo')
num_prim(x)
'''
___________________________________new separador_______________________________________
'''
import func_
func_.verifc_numPrimo(x)
val_bool = func_.return_numPrimo(x)
print(val_bool)


