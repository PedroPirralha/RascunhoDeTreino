print('digite c para Celsius, k para Kelvin, f para Fahrenheit\n ')
temperatura = int(input('digite a temperatura :'))
type_temp = str(input('digite em qual temperatura esta :'))
converter_em = str(input('digite em qual temperatura voce deseja converter :'))
print('\ntodos os os valores são aproximados ')
def conversor (temeratura, type_temp, converter_em):
    if type_temp == 'c':
        if converter_em == 'f':
            return ('{} graus Celsius e igual {} graus Fahrenheit'.format(temeratura, (9*temeratura+160)/5))
        elif converter_em == 'k':
            return ('{} graus Celsius e igual {} graus Kelvin'.format(temperatura, float(temperatura + 273)))
        elif converter_em == 'c':
            return('{} graus Celsius e igual {} graus Celcius'.format(temperatura, temperatura))
    if type_temp == 'f':
        if converter_em == 'k':
            return('{} graus Fahrenheit e igual {:.1f} graus kelvin'.format(temperatura,float( (((temperatura-32)*5) + 2457) / 9 )))

print(conversor(temperatura, type_temp, converter_em))