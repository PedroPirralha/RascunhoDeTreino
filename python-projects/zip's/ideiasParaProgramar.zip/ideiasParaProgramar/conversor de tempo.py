# conversor
print('"escrever somente h para hora m para minutos s para segundo" e o valor"')

def conv_tempo(converter, valor, convertido):
    if convertido == 'h':
        if converter == 'm':
            return ('{} hora(s) e igual a {} minutos'.format(valor, 60 * int(valor)))
        elif converter == 's':
            return('{} hora(s) e igual a {} segundos'.format(valor, int(valor) * 3600))
        else:
            return ('{} hora(s) e igual a {} hora(s)'.format(valor, valor))

    if convertido == 'm':
        if converter == 's':
            return ('{} minutos e igual a {} segundos'.format(valor, 60 * int(valor)))
        elif converter == 'h':
            return ('{} minutos e igual a {:.2f} horas'.format(valor,  0.0166667*float(valor) ))
        else:
            return ('{} minutos e igual a {} minutos'.format(valor,valor))

    if convertido ==  's':
        if converter == 'h':
            return ('{} segundos é igual a {:.4f} horas'.format(valor, float(valor) * 0.000277778))
        elif converter == 'm':
            return ('{} segundos e igua a {:.3f} minutos'.format(valor, float(valor) * 0.0166667))
        else:
            return ('{} segundos e igual a {} segundos'.format(valor, valor))

# fazer o conversor em minutos
converter = input('digite se voce quer converter em hora minutos ou segundo :')
print('')
convertido = input('digite se voce quer ver se o numero foi convertido\nem hora minutos segundo :')
print('')
valor = input('digite o valor em que voce ira converter :')
print('')
print(conv_tempo(convertido,valor,converter))